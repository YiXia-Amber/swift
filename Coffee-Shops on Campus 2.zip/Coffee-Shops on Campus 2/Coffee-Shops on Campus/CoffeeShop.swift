//
//  CoffeeShop.swift
//  Coffee-Shops on Campus
//
//  Created by 夏怡 on 26/11/2019.
//  Copyright © 2019 YiXia_201448617. All rights reserved.
//

import Foundation

struct shopWithInfo{
    var data: coffeeShop
    var distance: Double
}

struct coffeeShop: Decodable {
    let id: String
    let name: String
    let latitude: String
    let longitude: String
}

struct coffeeOnCampus: Decodable {
    let data: [coffeeShop]
    let code: Int
}

struct openTime: Decodable{
    let monday: String
    let tuesday: String
    let wednesday: String
    let thursday: String
    let friday: String
}

struct shopDetail: Decodable{
    let url: String?
    let phote_url: String?
    let phone_number: String?
    let opening_hours: openTime?
}

struct shopDetailWithCode: Decodable{
    let data: shopDetail
    let code: Int
}




