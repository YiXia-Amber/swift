//
//  DetailViewController.swift
//  Coffee-Shops on Campus
//
//  Created by Yi Xia on 28/11/2019.
//  Copyright © 2019 YiXia_201448617. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
      
    }
    
    var shopWithDetail: shopDetail?
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var context: NSManagedObjectContext?
   
    func getData(){
        var cacheBool = false //to check if the detail of this shop has been cached before
        
        //try to get the detail of the shop from cache
        context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "ShopsDetail")
        request.predicate = NSPredicate(format: "id <> %@", "")
        request.sortDescriptors?.append(NSSortDescriptor(key: "id", ascending: true))
        request.returnsObjectsAsFaults = false
        do {
        let results = try context?.fetch(request)
        
        if (results?.count)! > 0 { //if there is one...
            
            for result in results as! [ShopsDetail] {
                if result.id == id as String{
                    let url = result.url
                    let phoneNum = result.phone_number
                    let photoURL = result.phote_url
                    let monday = result.monday!
                    let tuesday = result.tuesday
                    let wednesday = result.wednesday
                    let thursday = result.thursday
                    let friday = result.friday
                    let time = openTime(monday: monday, tuesday: tuesday!, wednesday: wednesday!, thursday: thursday!, friday: friday!)
                    shopWithDetail = shopDetail(url: url, phote_url: photoURL, phone_number: phoneNum, opening_hours: time)
                    cacheBool = true // indicate that the data has been stored, so do not need to store again
                    self.drawView()
                }
                     
            }
            }}catch{
            print("no cache found")
            }
        
        if !cacheBool{ //if there is no cached data for the shop, try to get the data from API
          if let url = URL(string: "https://dentistry.liverpool.ac.uk/_ajax/coffee/info/?id=\(id)") {
            let session = URLSession.shared
        session.dataTask(with: url) { (data, response, err) in
               guard let jsonData = data else {
                  print("error")
                  return }
              do{
                  let decoder = JSONDecoder()
                  let shopInfo = try decoder.decode(shopDetailWithCode.self, from: jsonData)
                  self.shopWithDetail = shopInfo.data
                  DispatchQueue.main.async {
                    
                    self.drawView()
                    //save shopWithDetail and id to coredata
                    let newShopDetail = NSEntityDescription.insertNewObject(forEntityName: "ShopsDetail", into: self.context!) as! ShopsDetail
                    newShopDetail.id = id
                    newShopDetail.phone_number = self.shopWithDetail?.phone_number
                    newShopDetail.phote_url = self.shopWithDetail?.phote_url
                    newShopDetail.monday = self.shopWithDetail?.opening_hours?.monday
                    newShopDetail.tuesday = self.shopWithDetail?.opening_hours?.tuesday
                    newShopDetail.wednesday = self.shopWithDetail?.opening_hours?.wednesday
                    newShopDetail.thursday = self.shopWithDetail?.opening_hours?.thursday
                    newShopDetail.friday = self.shopWithDetail?.opening_hours?.friday
                    newShopDetail.url = self.shopWithDetail?.url
                    
                    do {
                        try self.context?.save() //save the detail of the shop
                        print("Saved")
                    } catch {
                        print("there was an error")
                    }
                    
                  }
              } catch let jsonErr {
                print("Error decoding JSON", jsonErr)
               
              }
          }.resume()
         }
        }
    }
    
 

    
    
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var theOpenTime: UILabel!
    @IBOutlet weak var theURL: UILabel!
    @IBOutlet weak var thePhoneNum: UILabel!
    
    func drawView(){
        //display the detail of the shop
        if let urlNilCheck = shopWithDetail?.url {
            theURL.text = " Website: \(shopWithDetail!.url!)"
        }
        if let phoneNilCheckNil = shopWithDetail!.phone_number{
            thePhoneNum.text = " Phone Number: \(shopWithDetail!.phone_number!)"
        }
        if let timeNilCheck = shopWithDetail?.opening_hours{
            theOpenTime.text = " Open Time:\n Monday: \(shopWithDetail!.opening_hours!.monday) \n Tuesday: \(shopWithDetail!.opening_hours!.tuesday)\n Wednesday: \(shopWithDetail!.opening_hours!.wednesday)\n Thursday: \(shopWithDetail!.opening_hours!.thursday)\n Friday: \(shopWithDetail!.opening_hours!.friday)"
        }
        
        if let photoNilCheck = shopWithDetail?.phote_url{
            let url = URL(string:shopWithDetail!.phote_url!)
            let data = try! Data(contentsOf: url!)
            var getImage = UIImage(data: data)
            myImage = UIImageView(image: getImage)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
