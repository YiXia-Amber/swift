//
//  ViewController.swift
//  Coffee-Shops on Campus
//
//  Created by Yi Xia on 25/11/2019.
//  Copyright © 2019 YiXia_201448617. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import CoreData

var id = "1"


class ViewController: UIViewController,UISearchBarDelegate,UITableViewDelegate, UITableViewDataSource, MKMapViewDelegate, CLLocationManagerDelegate{

    
    var Shops = [coffeeShop]() //shops from API
    var ShopstoDisplay = [coffeeShop]() //shops that will be displayed on the table
    @IBOutlet weak var mySearch: UISearchBar!
    @IBOutlet weak var myMap: MKMapView!
    @IBOutlet weak var myTable: UITableView!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        shopsWithDistance.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle,reuseIdentifier: "myCell")
        cell.textLabel?.text = "\(shopsWithDistance[indexPath.row].data.name)"
        cell.detailTextLabel?.text = "Distance: \(Int(shopsWithDistance[indexPath.row].distance))m"
        return cell
    }
    
    var locationManager = CLLocationManager()
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var context: NSManagedObjectContext?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view
        var coffeeShops: coffeeOnCampus?
        var coffeeShopsFromCache: coffeeOnCampus?
        var shopCache: coffeeShop
        var shopsCache = [coffeeShop]()
        
        //1.check the cache
        context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "CoffeeShops")
        request.predicate = NSPredicate(format: "id <> %@", "")
        request.sortDescriptors?.append(NSSortDescriptor(key: "id", ascending: true))
        request.returnsObjectsAsFaults = false
        do {
          let results = try context?.fetch(request)
          if (results?.count)! > 0 { //if there is cached data for coffeeShops
              var code = 0
              for result in results as! [CoffeeShops] {
                  let name = result.name
                  let lat = result.latitude
                  let lon = result.longitude
                  let id = result.id
                  code = Int(result.code)
                  shopCache = coffeeShop(id: id!, name: name!, latitude: lat!, longitude: lon!)
                  shopsCache.append(shopCache)
              }
            
              coffeeShopsFromCache = coffeeOnCampus(data: shopsCache, code: code)
              Shops = coffeeShopsFromCache!.data
              ShopstoDisplay = Shops
              self.drawMap()
              self.loadMap()
          }
        }catch{
            print("no cache found")
        }
        
        
        //2.try to get data from API
        if let url = URL(string: "https://dentistry.liverpool.ac.uk/_ajax/coffee/") {
        let session = URLSession.shared
        session.dataTask(with: url) { (data, response, err) in
             guard let jsonData = data else {
                print("error")
                return }
            do{
                let decoder = JSONDecoder()
                let shops = try decoder.decode(coffeeOnCampus.self, from: jsonData)
                var count = 0
                for aShop in shops.data {
                    count += 1
                    print("\(aShop.id)  \(aShop.name)")
                }
                coffeeShops = shops
                DispatchQueue.main.async {
                    self.Shops = coffeeShops!.data
                    self.Shops = self.ShopstoDisplay
                    self.drawMap()
                    self.loadMap()
                    
                    //compare the cached data and data from API
                    //if cached data is same as the data from API, the cached data does not need to be modified
                    //if cached data is different from json data, then change the cache
                    if !self.compareCache_Json(cache: coffeeShopsFromCache,jsonData: coffeeShops!){
                      //To change to cache
                      //(1) delete the cached data
                      do {
                          let results = try self.context?.fetch(request)
                          for object in results as! [CoffeeShops] {
                              self.context?.delete(object as NSManagedObject)
                          }
                        
                      } catch {
                          print("couldn't fetch ")
                      }
                     
                      //(2) Store the data from API to Core Data
                      for item in coffeeShops!.data{
                          let newShop = NSEntityDescription.insertNewObject(forEntityName: "CoffeeShops", into: self.context!) as! CoffeeShops
                          newShop.name = item.name
                          newShop.id = item.id
                          newShop.latitude = item.latitude
                          newShop.longitude = item.longitude
                          newShop.code = Int16(coffeeShops!.code)
                        
                          do {
                              try self.context?.save()
                              print("Saved")
                          } catch {
                              print("there was an error")
                          }
                      }
                    }
                }
                
            } catch let jsonErr {
                print("Error decoding JSON", jsonErr)
                //let Shops get core data
            }
        }.resume()
        }
        print(coffeeShops?.data.count as Any)
      
    }
    
    func loadMap(){
        locationManager.delegate = self as CLLocationManagerDelegate
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    

    var shopsWithDistance = [shopWithInfo]()
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locationOfUser = locations[0]
        let latitude = locationOfUser.coordinate.latitude
        let longitude = locationOfUser.coordinate.longitude
        let latDelta: CLLocationDegrees = 0.002
        let lonDelta: CLLocationDegrees = 0.002
        let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: lonDelta)
        let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let region = MKCoordinateRegion(center: location, span: span)
        self.myMap.setRegion(region, animated: true)
        
        //get the distance from user to coffee shops and put them in shopsWithDistance[] in ascending order
        shopsWithDistance = [shopWithInfo]()
        var shop_Distance:shopWithInfo
        var check = 0
        for theShop in ShopstoDisplay{
            let toSort = CLLocation(latitude: Double(theShop.latitude)!, longitude:Double(theShop.longitude)!)
            let theDistance = locationOfUser.distance(from: toSort) //calculate the distance from user to coffee shop
            shop_Distance = shopWithInfo(data: theShop, distance: theDistance)
            var theIndex = 0
            if check == 0{ //check if there are any elements in shopsWithDistance[]
                shopsWithDistance.append(shop_Distance) //if not, add the shop data with distance value to shopsWithDistance[] directly
            }else{ //if there are elements in shopsWithDistance[], add the shop data with distance value to shopsWithDistance[] in ascending order
                var continueCheck = 1
                for shopInArray in shopsWithDistance{ //compare the new element with other element in shopsWithDistance[]
                   if theDistance < shopInArray.distance && continueCheck == 1{ //if the distance value of the new element is less than the value of shopInArray, than insert the new element before the element: shopInArray
                       continueCheck = 0 //stop comparing the new element with other elements
                       shopsWithDistance.insert(shop_Distance, at:theIndex)
                   }
                   theIndex = theIndex + 1
                }
                if continueCheck == 1 { //if the distance value of the new element is longer than other element in shopsWithDistance[]
                    shopsWithDistance.append(shop_Distance) //put the new element in the end of array
                }
            }
            check = 1
        }

        self.myTable.reloadData()
      
    }
    
    func drawMap(){
        for shop in Shops{
            let coordinate = CLLocationCoordinate2D(latitude: Double(shop.latitude)!, longitude: Double(shop.longitude)!)
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = shop.name
            myMap.addAnnotation(annotation)
        }
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let lat = view.annotation?.coordinate.latitude
        let lon = view.annotation?.coordinate.longitude
        //get the id of the selected shop
        var check = 0
        while check == 0{
            for shop in Shops{
                if Double(shop.latitude) == lat{
                    if Double(shop.longitude) == lon{
                        check = 1
                        id = shop.id
                    }
                }
            }
        }
        performSegue(withIdentifier: "toDetailView", sender: nil)
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        print(searchText)
        
        ShopstoDisplay = [coffeeShop]()
        // show all the shops' information if no search content
        if searchText == "" {
            ShopstoDisplay = Shops
        }
        else { // compare the search content with data(shop name) from coffee shops
            for shop in Shops{
                if shop.name.lowercased().contains(searchText.lowercased()){
                    ShopstoDisplay.append(shop)
                }
            }
        }
        self.myTable.reloadData()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
         mySearch.resignFirstResponder()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        mySearch.resignFirstResponder()
        mySearch.text = ""
        ShopstoDisplay = Shops
        myTable.reloadData()
    }
    
    //function to compare two 'coffeeOnCampus' data
    func compareCache_Json(cache:coffeeOnCampus?,jsonData:coffeeOnCampus)->Bool{
        var bool = true
        if cache?.code == jsonData.code{
            if cache?.data.count == jsonData.data.count{
                let count = cache?.data.count
                var index = 0
                while index < count!{
                    if !compareShopDetail(shop1: (cache?.data[index])!, shop2: jsonData.data[index]){
                        bool = true
                    }
                    index = index + 1
                }
             }else{bool = false}
        }else{bool = false}
        return bool
    }

    //function to compare two 'coffeeShop' data
    func compareShopDetail(shop1:coffeeShop,shop2:coffeeShop)->Bool{
       if shop1.id == shop2.id{
            if shop2.latitude == shop2.latitude{
                if shop1.longitude == shop2.longitude{
                    if shop1.name == shop2.name{
                         return true
                    }
                }
            }
        }
        return false
    }
    

}

