//
//  CoffeeShops+CoreDataClass.swift
//  Coffee-Shops on Campus
//
//  Created by 夏怡 on 30/11/2019.
//  Copyright © 2019 YiXia_201448617. All rights reserved.
//
//

import Foundation
import CoreData

@objc(CoffeeShops)
public class CoffeeShops: NSManagedObject {

}
