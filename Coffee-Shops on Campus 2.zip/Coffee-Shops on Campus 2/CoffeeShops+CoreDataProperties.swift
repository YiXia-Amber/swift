//
//  CoffeeShops+CoreDataProperties.swift
//  Coffee-Shops on Campus
//
//  Created by 夏怡 on 30/11/2019.
//  Copyright © 2019 YiXia_201448617. All rights reserved.
//
//

import Foundation
import CoreData


extension CoffeeShops {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CoffeeShops> {
        return NSFetchRequest<CoffeeShops>(entityName: "CoffeeShops")
    }

    @NSManaged public var code: Int16
    @NSManaged public var id: String?
    @NSManaged public var name: String?
    @NSManaged public var latitude: String?
    @NSManaged public var longitude: String?

}
