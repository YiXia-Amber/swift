//
//  ShopsDetail+CoreDataProperties.swift
//  Coffee-Shops on Campus
//
//  Created by 夏怡 on 30/11/2019.
//  Copyright © 2019 YiXia_201448617. All rights reserved.
//
//

import Foundation
import CoreData


extension ShopsDetail {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ShopsDetail> {
        return NSFetchRequest<ShopsDetail>(entityName: "ShopsDetail")
    }

    @NSManaged public var id: String?
    @NSManaged public var url: String?
    @NSManaged public var phote_url: String?
    @NSManaged public var phone_number: String?
    @NSManaged public var monday: String?
    @NSManaged public var tuesday: String?
    @NSManaged public var wednesday: String?
    @NSManaged public var thursday: String?
    @NSManaged public var friday: String?

}
